import './App.css';
import Home from './components/Home';
import Joingame from './components/Joingame';

function App() {
  return (
    <>
    {/* <Home /> */}
    <Joingame />
    </>
  );
}

export default App;

import React from 'react'
import './Joingame.css'

function Joingame() {
  return (
    <>
    <div className="team-container">
        <div className="team-name">
            <h1 >Team Name</h1>

        <div className='Team-1'>
            <form action="">
                <input type="text" />
                <input type="text" />
                <input type="text" />
                <input type="text" />
                <input type="text" />
            </form>
        </div>
        </div>
        <div className='Team-2'>
            <form action="">
                <input type="text" />
                <input type="text" />
                <input type="text" />
                <input type="text" />
                <input type="text" />
            </form>
        </div>
    </div>
    </>
  )
}

export default Joingame